﻿@echo off
chcp 65001 >nul
title Đang Cập Nhật autoRegSnapADB...
echo ========================================================
echo   ĐANG CẬP NHẬT PHẦN MỀM LÊN PHIÊN BẢN MỚI
echo   Vui lòng đợi giây lát...
echo ========================================================
timeout /t 2 /nobreak >nul

:wait_loop
tasklist /FI "PID eq 20688" 2>nul | find /I "20688" >nul
if not errorlevel 1 (
    timeout /t 1 /nobreak >nul
    goto wait_loop
)

echo Đang sao chép tệp mới...
xcopy "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows\_update_temp\*" "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows\" /E /Y /I /Q >nul

echo Dọn dẹp tệp tạm...
rmdir /S /Q "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows\_update_temp" >nul 2>&1
del /Q "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows\update_package.zip" >nul 2>&1

echo Khởi động lại ứng dụng...
start "" "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows\autoRegSnapADB.exe"
exit
