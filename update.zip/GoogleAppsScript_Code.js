/**
 * GOOGLE APPS SCRIPT CHO GOOGLE SHEET TỰ ĐỘNG ĐẨY TÀI KHOẢN SNAPCHAT
 * Cập nhật v3.1:
 * - Khi là ngày mới / nước mới: LUÔN TẠO CỘT MỚI Ở BÊN PHẢI NGOÀI CÙNG (sheet.getLastColumn() + 1).
 *   Tuyệt đối KHÔNG nhảy vào các cột trống ở giữa bảng!
 * - Quét tìm cột cùng ngày + cùng nước từ phải sang trái (ưu tiên cột mới nhất).
 * - Tự động mở rộng thêm cột nếu sheet chạm giới hạn số cột tối đa.
 * - Tự động thay {country} thành nước thực tế (ví dụ: ae, sa, us...).
 * - Cùng ngày + cùng nước -> Luôn đẩy chung vào 1 cột duy nhất!
 * - Tự động tìm dòng trống tiếp theo (từ dòng 5) và cập nhật số lượng (Hàng 4).
 * 
 * Hướng dẫn cài đặt / cập nhật:
 * 1. Mở Google Sheet cần lưu tài khoản.
 * 2. Vào menu "Tiện ích mở rộng" (Extensions) -> chọn "Apps Script".
 * 3. Xóa hết code cũ, dán toàn bộ đoạn code này vào.
 * 4. Bấm "Triển khai" (Deploy) -> chọn "Quản lý tùy chọn triển khai" (Manage deployments) hoặc "Tùy chọn triển khai mới" (New deployment).
 * 5. Chọn "Ứng dụng web" (Web app) -> Thực thi dưới dạng: Tôi (Me) -> Ai có quyền: Bất kỳ ai (Anyone) -> Triển khai (Deploy).
 */

function doGet(e) {
  return handleRequest(e);
}

function doPost(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  var lock = LockService.getScriptLock();
  // Khóa tối đa 30 giây để tránh xung đột khi nhiều luồng/máy cùng đẩy lên 1 lúc
  var hasLock = lock.tryLock(30000);
  if (!hasLock) {
    return jsonResponse({
      status: "error",
      message: "Hệ thống đang bận ghi dữ liệu từ thiết bị khác, vui lòng thử lại sau 2 giây."
    });
  }

  try {
    var params = {};
    if (e && e.parameter) {
      for (var key in e.parameter) {
        params[key] = e.parameter[key];
      }
    }

    if (e && e.postData && e.postData.contents) {
      try {
        var postBody = JSON.parse(e.postData.contents);
        for (var k in postBody) {
          params[k] = postBody[k];
        }
      } catch (err) {
        // Body không phải JSON hoặc rỗng
      }
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var action = (params.action || (params.account ? "append_account" : "get_sheets")).toLowerCase();

    // 1. LẤY DANH SÁCH SHEET (TABS)
    if (action === "get_sheets" || action === "ping") {
      var sheetList = [];
      var sheets = ss.getSheets();
      for (var i = 0; i < sheets.length; i++) {
        sheetList.push(sheets[i].getName());
      }
      return jsonResponse({
        status: "success",
        version: "3.3",
        spreadsheetTitle: ss.getName(),
        sheets: sheetList,
        message: "v3.3 | Kết nối thành công! Đã tìm thấy " + sheetList.length + " sheet."
      });
    }

    // 2. GHI TÀI KHOẢN VÀO SHEET
    if (action === "append_account" || params.account) {
      var sheetName = params.sheetName ? String(params.sheetName).trim() : "";
      var sheet = null;
      if (sheetName) {
        sheet = ss.getSheetByName(sheetName);
      }
      if (!sheet) {
        sheet = ss.getActiveSheet();
      }

      var country = (params.country || "ae").trim().toLowerCase();
      var rawNote = (params.note || (country + " 1024,ver mới")).trim();
      // Thay thế triệt để biến {country} thành tên nước thực tế
      var note = rawNote.replace(/\{country\}/gi, country).replace(/\{COUNTRY\}/gi, country.toUpperCase());
      var subNote = (params.subNote !== undefined && params.subNote !== null) ? String(params.subNote).trim() : "";
      var account = (params.account || "").trim();

      var timeZone = ss.getSpreadsheetTimeZone() || "GMT+7";
      var rawDate = (params.date || "").trim();
      var targetDate = normalizeDate(rawDate, timeZone);
      if (!targetDate) {
        targetDate = Utilities.formatDate(new Date(), timeZone, "dd/MM/yyyy");
      }

      var specifiedColStr = (params.targetColumn || params.specifiedColumn || "").trim();
      var specifiedCol = parseColumnIndex(specifiedColStr);

      var targetCol = -1;

      if (specifiedCol > 0) {
        // NẾU NGƯỜI DÙNG CHỈ ĐỊNH CỘT CỤ THỂ (VD: CỘT R, CỘT 18...)
        targetCol = specifiedCol;
        var maxCols = sheet.getMaxColumns();
        if (targetCol > maxCols) {
          sheet.insertColumnsAfter(maxCols, Math.max(10, targetCol - maxCols));
        }
        var r1Curr = String(sheet.getRange(1, targetCol).getValue() || "").trim();
        var r3Curr = String(sheet.getRange(3, targetCol).getValue() || "").trim();
        if (!r1Curr) sheet.getRange(1, targetCol).setValue(note);
        if (subNote && !sheet.getRange(2, targetCol).getValue()) sheet.getRange(2, targetCol).setValue(subNote);
        if (!r3Curr) sheet.getRange(3, targetCol).setNumberFormat("@").setValue(targetDate);
        if (!sheet.getRange(4, targetCol).getValue()) sheet.getRange(4, targetCol).setValue(0);
      } else {
        // QUÉT TỰ ĐỘNG TÌM CỘT: CÙNG NGÀY VÀ CÙNG NƯỚC (Quét từ phải sang trái để ưu tiên cột mới nhất)
        var lastCol = Math.max(sheet.getLastColumn(), 1);
        var headerDisplay = sheet.getRange(1, 1, 3, lastCol).getDisplayValues();
        var r1Row = headerDisplay[0]; // Hàng 1: Note phân loại
        var r3Row = headerDisplay[2]; // Hàng 3: Ngày tháng hiển thị

        for (var c = lastCol - 1; c >= 0; c--) {
          var colIndex = c + 1;
          var r1Val = String(r1Row[c] || "").trim();
          var r3Val = String(r3Row[c] || "").trim();

          var r1Lower = r1Val.toLowerCase();
          var noteLower = note.toLowerCase();
          var isNoteMatch = false;

          if (r1Lower === noteLower) {
            isNoteMatch = true;
          } else if (r1Lower.indexOf(country) !== -1 || r1Lower.indexOf("{country}") !== -1) {
            if (noteLower.indexOf("bypass") !== -1) {
              isNoteMatch = (r1Lower.indexOf("bypass") !== -1);
            } else if (r1Lower.indexOf("bypass") !== -1) {
              isNoteMatch = false;
            } else {
              isNoteMatch = true;
            }
          }

          // CÙNG NGÀY + CÙNG NƯỚC -> CHÍNH XÁC LÀ CỘT NÀY!
          if (isNoteMatch && isSameDate(r3Val, targetDate)) {
            targetCol = colIndex;
            if (r1Val.indexOf("{country}") !== -1 || r1Val.indexOf("{COUNTRY}") !== -1) {
              sheet.getRange(1, targetCol).setValue(note);
            }
            break;
          }
        }

        // NẾU CHƯA CÓ CỘT CHO NGÀY/NƯỚC NÀY -> LUÔN TẠO Ở BÊN PHẢI NGOÀI CÙNG (CỘT CUỐI CÙNG + 1)
        // Tuyệt đối không chèn vào các cột trống ở giữa bảng
        if (targetCol === -1) {
          targetCol = sheet.getLastColumn() + 1;
          var maxCols = sheet.getMaxColumns();
          if (targetCol > maxCols) {
            sheet.insertColumnsAfter(maxCols, Math.max(10, targetCol - maxCols));
          }
          sheet.getRange(1, targetCol).setValue(note);
          if (subNote) {
            sheet.getRange(2, targetCol).setValue(subNote);
          }
          // Lưu dạng text thuần @ để không bị Google Sheet tự đổi tháng/ngày
          sheet.getRange(3, targetCol).setNumberFormat("@").setValue(targetDate);
          sheet.getRange(4, targetCol).setValue(0);
        }
      }

      // TÌM DÒNG TRỐNG TIẾP THEO TRONG CỘT ĐÓ (TỪ DÒNG 5 TRỞ ĐI)
      var maxRows = sheet.getMaxRows();
      if (maxRows < 10) {
        sheet.insertRowsAfter(maxRows, 50);
        maxRows = sheet.getMaxRows();
      }

      var colValues = sheet.getRange(5, targetCol, Math.max(1, maxRows - 4), 1).getValues();
      var targetRow = -1;
      var currentCount = 0;

      for (var r = 0; r < colValues.length; r++) {
        var cellVal = colValues[r][0];
        if (cellVal !== "" && cellVal !== null && cellVal !== undefined) {
          currentCount++;
        } else if (targetRow === -1) {
          targetRow = 5 + r;
        }
      }

      if (targetRow === -1) {
        sheet.insertRowAfter(maxRows);
        targetRow = maxRows + 1;
      }

      // GHI TÀI KHOẢN VÀO DÒNG TRỐNG CỦA CỘT
      if (account) {
        var cell = sheet.getRange(targetRow, targetCol);
        cell.setValue(account);
        try {
          cell.clearFormat();
          // 1. Ép màu nền toàn bộ các dòng tài khoản trong cột thành màu trắng tinh khiết (#ffffff)
          var totalAccRows = Math.max(1, targetRow - 4);
          var accRange = sheet.getRange(5, targetCol, totalAccRows, 1);
          accRange.setBackground("#ffffff");
          accRange.setFontColor("#000000");

          // 2. Xóa triệt để các quy tắc định dạng có điều kiện (Conditional Formatting) nếu có trên cột này
          var rules = sheet.getConditionalFormatRules();
          if (rules && rules.length > 0) {
            var newRules = [];
            for (var rIdx = 0; rIdx < rules.length; rIdx++) {
              var rRanges = rules[rIdx].getRanges();
              var touchesCol = false;
              for (var rg = 0; rg < rRanges.length; rg++) {
                if (rRanges[rg].getColumn() <= targetCol && rRanges[rg].getLastColumn() >= targetCol) {
                  touchesCol = true;
                  break;
                }
              }
              if (!touchesCol) newRules.push(rules[rIdx]);
            }
            if (newRules.length !== rules.length) {
              sheet.setConditionalFormatRules(newRules);
            }
          }
        } catch (colorErr) {}

        currentCount++;
        sheet.getRange(4, targetCol).setValue(currentCount);
      }

      return jsonResponse({
        status: "success",
        version: "3.3",
        sheetName: sheet.getName(),
        column: targetCol,
        row: targetRow,
        count: currentCount,
        country: country,
        note: note,
        message: "v3.3 | Đã lưu vào Sheet: " + sheet.getName() + " | Cột " + targetCol + " | Dòng " + targetRow + " (Tổng: " + currentCount + ")"
      });
    }

    return jsonResponse({
      status: "error",
      message: "Hành động (action) không hợp lệ: " + action
    });
  } catch (err) {
    return jsonResponse({
      status: "error",
      message: "Lỗi xử lý: " + (err.message || err.toString())
    });
  } finally {
    lock.releaseLock();
  }
}

function isSameDate(d1Str, d2Str) {
  if (!d1Str || !d2Str) return false;
  var s1 = String(d1Str).trim();
  var s2 = String(d2Str).trim();
  if (s1 === s2) return true;

  var p1 = s1.split(/[\/\-\.]/);
  var p2 = s2.split(/[\/\-\.]/);
  if (p1.length >= 3 && p2.length >= 3) {
    var day1 = parseInt(p1[0], 10);
    var mon1 = parseInt(p1[1], 10);
    var yr1 = parseInt(p1[2], 10);
    var day2 = parseInt(p2[0], 10);
    var mon2 = parseInt(p2[1], 10);
    var yr2 = parseInt(p2[2], 10);

    // Trùng khớp chuẩn dd/MM/yyyy
    if (day1 === day2 && mon1 === mon2 && yr1 === yr2) return true;
    // Trùng khớp nếu 1 trong 2 ô bị hệ thống Google Sheet đảo thành MM/dd/yyyy
    if (day1 === mon2 && mon1 === day2 && yr1 === yr2) return true;
  }
  return false;
}

function normalizeDate(val, tz) {
  if (!val) return "";
  if (val instanceof Date) {
    var d = ("0" + val.getDate()).slice(-2);
    var m = ("0" + (val.getMonth() + 1)).slice(-2);
    return d + "/" + m + "/" + val.getFullYear();
  }
  var s = String(val).trim();
  var match = s.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})/);
  if (match) {
    var day = ("0" + match[1]).slice(-2);
    var month = ("0" + match[2]).slice(-2);
    return day + "/" + month + "/" + match[3];
  }
  return s;
}

function jsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// Chuyển đổi tên cột (ví dụ 'A' -> 1, 'R' -> 18, 'AA' -> 27 hoặc số '18' -> 18)
function parseColumnIndex(colInput) {
  if (!colInput) return -1;
  var s = String(colInput).trim().toUpperCase();
  if (/^\d+$/.test(s)) {
    return parseInt(s, 10);
  }
  var col = 0;
  for (var i = 0; i < s.length; i++) {
    var code = s.charCodeAt(i);
    if (code >= 65 && code <= 90) {
      col = col * 26 + (code - 64);
    } else {
      return -1;
    }
  }
  return col > 0 ? col : -1;
}
