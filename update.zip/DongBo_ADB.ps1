# DongBo_ADB.ps1
$ErrorActionPreference = "SilentlyContinue"

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "   DONG BO ADB CHUAN - CHONG XUNG DOT SNAP, MICHANGER & XIAOWEI" -ForegroundColor Yellow
Write-Host "=====================================================================" -ForegroundColor Cyan

# 1. Tat cac tien trinh ADB va MiChanger
Write-Host "[1/3] Dang dong cac tien trinh ADB va MiChanger dang chay..." -ForegroundColor White
Stop-Process -Name "adb" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "MiChangerPlus" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "MiChangerPlus FULL" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

$srcDir = "D:\code\autoRegSnapAdb\autoRegSnapADB\bin\Debug\net9.0-windows"
$files = @("adb.exe", "AdbWinApi.dll", "AdbWinUsbApi.dll")

# 2. Dong bo sang MiChangerPlus
Write-Host "[2/3] Dang dong bo sang MiChangerPlus..." -ForegroundColor White
$mcDirs = @(
    "D:\ToolsGoogle\MiChangerPlus\app-5.2.1\Resources",
    "D:\ToolsGoogle\MiChangerPlus\app-5.2.1\Resources\viewscreen10",
    "D:\ToolsGoogle\MiChangerPlus\app-5.2.1\Resources\viewscreen11",
    "D:\ToolsGoogle\Michanger5.4CrackRoom10\Michanger5.4Crack\Michanger FULL-5.4\app-5.4.0\Resources",
    "D:\ToolsGoogle\Michanger5.4CrackRoom10\Michanger5.4Crack\Michanger FULL-5.4\app-5.4.0\Resources\viewscreen10",
    "D:\ToolsGoogle\Michanger5.4CrackRoom10\Michanger5.4Crack\Michanger FULL-5.4\app-5.4.0\Resources\viewscreen11"
)

foreach ($dir in $mcDirs) {
    if (Test-Path $dir) {
        foreach ($f in $files) {
            $src = Join-Path $srcDir $f
            $dst = Join-Path $dir $f
            $bak = Join-Path $dir ($f + ".bak")
            if (Test-Path $dst) {
                if (!(Test-Path $bak)) {
                    Copy-Item -Path $dst -Destination $bak -Force -ErrorAction SilentlyContinue
                }
            }
            Copy-Item -Path $src -Destination $dst -Force -ErrorAction SilentlyContinue
        }
        Write-Host "  [OK] Dong bo thanh cong: $dir" -ForegroundColor Green
    }
}

# 3. Dong bo sang XiaoWei
Write-Host "[3/3] Dang dong bo sang XiaoWei Android..." -ForegroundColor White
$xwDir = "C:\Program Files (x86)\xiaowei_android\tools"
if (Test-Path $xwDir) {
    foreach ($f in $files) {
        $src = Join-Path $srcDir $f
        $dst = Join-Path $xwDir $f
        $bak = Join-Path $xwDir ($f + ".bak")
        if (Test-Path $dst) {
            if (!(Test-Path $bak)) {
                Copy-Item -Path $dst -Destination $bak -Force -ErrorAction SilentlyContinue
            }
        }
        Copy-Item -Path $src -Destination $dst -Force -ErrorAction SilentlyContinue
    }
    Write-Host "  [OK] Dong bo thanh cong: $xwDir" -ForegroundColor Green
} else {
    Write-Host "  [Bo qua] Khong tim thay thu muc: $xwDir" -ForegroundColor Gray
}

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "[HOAN TAT] Da dong bo toan bo ADB sang cung 1 phien ban chuan 36.0.0!" -ForegroundColor Green
Write-Host "Gio ban co the mo ca Snap Tool, MiChanger va XiaoWei cung luc ma KHONG bi:" -ForegroundColor White
Write-Host "  1. Dut ket noi ADB" -ForegroundColor White
Write-Host "  2. Den man hinh scrcpy" -ForegroundColor White
Write-Host "  3. Treo do phan mem" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Cyan
