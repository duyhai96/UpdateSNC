@echo off
title Dong Bo ADB
set "PS1_PATH=%~dp0DongBo_ADB.ps1"
if not exist "%PS1_PATH%" set "PS1_PATH=d:\code\autoRegSnapAdb\DongBo_ADB.ps1"
powershell -Command "Start-Process powershell -ArgumentList '-ExecutionPolicy Bypass -NoExit -File \"\"%PS1_PATH%\"\"' -Verb RunAs"
